This is a Python web scraping app to auto gain data from buildertrend (which is an app with no open API), and load maintenance analysis data and visulization autoed. 
There are progress bar to show the process of data scraping and report creating for user friendly (won't run unless have authorizaiton, just for showing logic）.
